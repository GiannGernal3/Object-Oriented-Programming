/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mmdc_proj;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Family
 */
public class SimpleLogin {
    public static void main (String [] args){
        Scanner scanner = new Scanner (System.in);
        String [] User = {"GiannGernale", "GabbyGernale", "PiaGernale", "DarwinGernale"};
        String [] Pass = {"1234", "1233", "1232", "1232"};
        
        System.out.println("Welcome to MotorPH!");
        System.out.println("User: ");
        String UserName = scanner.nextLine();
        
        System.out.println("Pass: ");
        String Password = scanner.nextLine();
        
        boolean LoggedIn = false;
        for(int i = 0; i < User.length; i++){
            if(UserName.equals(User[i]) && Password.equals(Pass[i])){
                LoggedIn = true;
                break;
            }
        }
        
        if (LoggedIn){
            System.out.println ("Login successful!");
        }else{
            System.out.println("Login Failed!");
        }
        scanner.close();
    }
    
}
