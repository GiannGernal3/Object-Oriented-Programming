/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Utilities;

/**
 *
 * @author Family
 */
public class Test {
    public static void amin (String []args){
        System.out.println("""
                           And I want to be an artist!Hello my name is Giann!
                           """);
        
    }
}
