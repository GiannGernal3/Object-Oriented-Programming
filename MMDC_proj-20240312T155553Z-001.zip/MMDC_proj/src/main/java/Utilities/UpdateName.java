/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Utilities;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author Family
 */
public class UpdateName {
    public static void main(String[] args) {
        String inputFile1 = "C:\\Users\\Family\\Downloads\\MotorPH Employee Data - Employee Details.csv";
        String inputFile2 = "C:\\Users\\Family\\Downloads\\Employee Attendance Record.csv";
        String outputFile = "C:\\Users\\Family\\Downloads\\Employee Attendance Record.csv";

        try {
            Map<String, String[]> dataMap = new HashMap<>();

            // Read data from the first CSV file
            try (Scanner scanner = new Scanner(new File(inputFile1))) {
                // Skip header
                if (scanner.hasNextLine()) {
                    scanner.nextLine();
                }

                while (scanner.hasNextLine()) {
                    String line = scanner.nextLine();
                    String[] parts = line.split(",");
                    if (parts.length >= 3) {
                        String employeeId = parts[0];
                        String[] names = {parts[1], parts[2]};
                        dataMap.put(employeeId, names);
                    }
                }
            }

            // Update data in the second CSV file
            List<String> outputLines = new ArrayList<>();
            try (BufferedReader reader = new BufferedReader(new FileReader(inputFile2))) {
                String line;
                // Read header
                if ((line = reader.readLine()) != null) {
                    outputLines.add(line); // Add header to the output
                }

                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(",");
                    if (parts.length >= 3) {
                        String employeeId = parts[0];
                        String[] names = dataMap.get(employeeId);
                        if (names != null) {
                            parts[1] = names[0]; // Update last name
                            parts[2] = names[1]; // Update first name
                        }
                    }
                    outputLines.add(String.join(",", parts));
                }
            }

            // Write updated data to the output file
            try (PrintWriter writer = new PrintWriter(new FileWriter(outputFile))) {
                for (String line : outputLines) {
                    writer.println(line);
                }
            }

            System.out.println("Data updated successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
