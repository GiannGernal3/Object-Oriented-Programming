/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author Family
 */
public class Employee {
    private String EmployeeID, FirstName, LastName, Birthday, Address, PhoneNum, SSS, PhilHealth, TIN, PagIbig, Position;
    private double BasicSal, GrossSemiMonthly, HourlyRate;
    
     public void readFromCSV(String filename, String ProvidedPassword) throws IOException, CsvValidationException {
        try (CSVReader csvReader = new CSVReader(new FileReader("MotorPH Employee Data - Employee Details.csv"))) {
            String[] headers = csvReader.readNext(); // Assuming the first line contains headers
            String[] data;
            while ((data = csvReader.readNext()) != null) {
                String EmployeeIDFromFile = data[0]; // Assuming the username is in the first column of the CSV 
                if (ProvidedPassword.equals(EmployeeIDFromFile)) {
                    // If the username and password match, populate the fields
                    EmployeeID = data[0];
                    FirstName = data[1];
                    LastName = data[2];
                    Birthday = data[3];
                    Address = data[4];
                    PhoneNum = data[5];
                    SSS = data[6];
                    PhilHealth = data[7];
                    TIN = data[8];
                    PagIbig = data[9];
                    Position = data[10];
                    BasicSal = Double.parseDouble(data[13].replace(",", ""));
                    GrossSemiMonthly = Double.parseDouble(data[17].replace(",",""));
                    HourlyRate = Double.parseDouble(data[18].replace(",", ""));
                    break; // Stop reading once the employee is found
                }
            }
        }
    }
     public String getEmployeeID() {
        return EmployeeID;
    }

    public String getFirstName() {
        return FirstName;
    }

    public String getLastName() {
        return LastName;
    }

    public String getBirthday() {
        return Birthday;
    }

    public String getAddress() {
        return Address;
    }

    public String getPhoneNum() {
        return PhoneNum;
    }

    public String getSSS() {
        return SSS;
    }

    public String getPhilHealth() {
        return PhilHealth;
    }

    public String getTIN() {
        return TIN;
    }

    public String getPagIbig() {
        return PagIbig;
    }

    public String getPosition() {
        return Position;
    }

    public double getBasicSal() {
        return BasicSal;
    }
    
    public double getGrossSemiMonthly() {
        return GrossSemiMonthly;
    }

    public double getHourlyRate() {
        return HourlyRate;
    }
}
