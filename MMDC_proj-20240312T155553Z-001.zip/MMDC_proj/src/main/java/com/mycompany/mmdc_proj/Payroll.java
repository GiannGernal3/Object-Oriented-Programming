/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.terminalassessment;
import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;
import java.io.FileReader;
import java.io.IOException;
/**
 *
 * @author Darwin
 */
public class Payroll {
    //---------------Employee Information Management---------------
    private String EmployeeID;
    private String FirstName;
    private String LastName;
    private String Birthday;
    private String Address;
    private String PhoneNumber;
    private String CivilStatus;
    private String Position;
    
    //EmployeeID
    public void setEmployeeID (String EmployeeID){
        this.EmployeeID = EmployeeID;
    }
    
    public String getEmployeeID(){
        return EmployeeID;
    }
    
    //FirstName
    public void setFirstName (String FirstName){
        this.FirstName = FirstName;
    }
    
    public String getFirstName(){
        return FirstName;
    }
    
    //LastName
    public void setLastName (String LastName){
        this.LastName = LastName;
    }
    
    public String getLastName(){
        return LastName;
    }
    
    //Birthday
    public void setBirthday (String Birthday){
        this.Birthday = Birthday;
    }
    
    public String getBirthday(){
        return Birthday;
    }
    
    //Address 
    public void setAddress (String Address){
        this.Address = Address;
    }
    
    public String getAddress(){
        return Address;
    }
    
    //PhoneNumber
    public void setPhoneNumber (String PhoneNumber){
        this.PhoneNumber = PhoneNumber;
    }
    
    public String getPhoneNumber(){
        return PhoneNumber;
    }
    
    //CivilStatus
    public void setCivilStatus (String CivilStatus){
        this.CivilStatus = CivilStatus;
    }
    
    public String getCivilStatus(){
        return CivilStatus;
    }
    
    //Position
    public void setPosition (String Position){
        this.Position = Position;
    }
    
    public String getPositions(){
        return Position;
    }
    
    
    //---------------Salary---------------
    private double HourlyRate;
    private double BasicSalary;
    private double GrossSalary;
    private double NetSalary;
    
    //HourltRate
    public void setHourlyRate(double HourlyRate){
        this.HourlyRate = HourlyRate;
    }
    
    public double getHourlyRate(){
        return HourlyRate;
    }
    
    //BasicSalary
    public void setBasicSalary(double BasicSalary){
        this.BasicSalary = BasicSalary;
    }
    
    public double getBasicSalary(){
        return BasicSalary;
    }
    
    //GrossSalary
    public void setGrossSalary(double GrossSalary){
        this.GrossSalary = GrossSalary;
    }
    
    public double getrossSalary(){
        return GrossSalary;
    }
    
    //NetSalary
    public void setNetSalary(double NetSalary){
        this.NetSalary = NetSalary;
    }
    
    public double getNetSalary(){
        return NetSalary;
    }
    
     public void loadEmployeeData(String csvFilePath) throws CsvValidationException{
        try (CSVReader reader = new CSVReader(new FileReader(csvFilePath))){
            String[] nextLine;
            while((nextLine = reader.readNext()) != null){
                setEmployeeID(nextLine[0]);
                setLastName(nextLine[1]);
            }
        }catch(IOException e){
            e.printStackTrace();
        }
    }
}
