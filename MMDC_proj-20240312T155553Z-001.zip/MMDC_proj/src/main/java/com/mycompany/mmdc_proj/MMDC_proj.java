/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mmdc_proj;

/**
 *
 * @author Family
 */
public class MMDC_proj {

    public static void main(String[] args) {
       Person person = new Person();
       person.setAge(68);
       person.setName("Giann");
       
       String personName = person.getName();
       int personAge = person.getAge();
       
       System.out.println(personName);
       System.out.println(personAge);
    }
}
