/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Utilities;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Family
 */
public class UpdateYear {
    public static void main(String[] args) {
        String inputFile = "C:\\Users\\Family\\Downloads\\Employee Attendance Record.csv";
        String outputFile = "C:\\Users\\Family\\Downloads\\Employee Attendance Record.csv";

        try {
            List<String> outputLines = new ArrayList<>();

            // Read data from the input CSV file and update the year
            try (BufferedReader reader = new BufferedReader(new FileReader(inputFile))) {
                String line;
                // Read header and add it to the output
                if ((line = reader.readLine()) != null) {
                    outputLines.add(line);
                }

                // Process each line of the input CSV
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(",");
                    if (parts.length >= 4) {
                        String dateString = parts[3].trim();
                        // Split the date into parts
                        String[] dateParts = dateString.split("/");
                        if (dateParts.length == 3) {
                            // Update the year to 2023
                            dateParts[2] = "2023";
                            // Reconstruct the updated date string
                            String updatedDate = String.join("/", dateParts);
                            // Replace the original date with the updated one
                            parts[3] = updatedDate;
                        }
                    }
                    // Add the updated line to the output
                    outputLines.add(String.join(",", parts));
                }
            }

            // Write the updated data to the output CSV file
            try (PrintWriter writer = new PrintWriter(new FileWriter(outputFile))) {
                for (String line : outputLines) {
                    writer.println(line);
                }
            }

            System.out.println("Attendance records updated successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
